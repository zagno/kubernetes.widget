#!/bin/bash

/usr/local/bin/kubectl get pods --all-namespaces -o json