#!/bin/bash

/usr/local/bin/kubectl get nodes -o json