#!/bin/bash

/usr/local/bin/kubectl get pods -n kube-system -o json