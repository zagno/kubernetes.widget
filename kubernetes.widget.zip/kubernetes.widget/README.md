# A collection of Kuberenetes widgets for Übersicht

Current there are 2 widgets in this repo.

### Pods

List all running pods and their statuses in the current context.

The status colour will change to red if the status is anything other than `Running`

### Nodes

List all running nodes in the current contenxt and some details about each node